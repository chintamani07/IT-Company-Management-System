﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Banking_System_Project
{
    class Sqlconnection
    {
        private string p;

        public Sqlconnection(string p)
        {
            // TODO: Complete member initialization
            this.p = p;
        }
    }
}
